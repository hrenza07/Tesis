package classes;

import java.util.Date;

public class Capacitacion implements java.io.Serializable{
	private Integer id_capacitacion;
	private String nombre;
	private String descripcion;
	private String lugar;
	private Date fecha_inicio;
	private Date fecha_fin;
	private Empleado empleado;
	public Integer getId_capacitacion() {
		return id_capacitacion;
	}
	public void setId_capacitacion(Integer id_capacitacion) {
		this.id_capacitacion = id_capacitacion;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public String getLugar() {
		return lugar;
	}
	public void setLugar(String lugar) {
		this.lugar = lugar;
	}
	public Date getFecha_inicio() {
		return fecha_inicio;
	}
	public void setFecha_inicio(Date fecha_inicio) {
		this.fecha_inicio = fecha_inicio;
	}
	public Date getFecha_fin() {
		return fecha_fin;
	}
	public void setFecha_fin(Date fecha_fin) {
		this.fecha_fin = fecha_fin;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	
	
}
