package classes;

import java.util.Date;

public class Educacion implements java.io.Serializable{
	private Integer id_educacion;
	private String titulo;
	private Date fecha_inicio;
	private Date fecha_fin;
	private Empleado empleado;
	public Integer getId_educacion() {
		return id_educacion;
	}
	public void setId_educacion(Integer id_educacion) {
		this.id_educacion = id_educacion;
	}
	public String getTitulo() {
		return titulo;
	}
	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}
	public Date getFecha_inicio() {
		return fecha_inicio;
	}
	public void setFecha_inicio(Date fecha_inicio) {
		this.fecha_inicio = fecha_inicio;
	}
	public Date getFecha_fin() {
		return fecha_fin;
	}
	public void setFecha_fin(Date fecha_fin) {
		this.fecha_fin = fecha_fin;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	
	
}
