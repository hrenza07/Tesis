package classes;

import java.util.HashSet;
import java.util.Set;

public class Puesto implements java.io.Serializable{
	private Integer id_puesto_trabajo;
	private String nombre;
	private String descripcion;
	private Double salario_min;
	private Double salario_max;
	private Set<Empleado> empleado = new HashSet<Empleado>(0);
	private Set<Objetivo> objetivo = new HashSet<Objetivo>(0);
	private Set<Criterio> criterio = new HashSet<Criterio>(0);
	public Integer getId_puesto_trabajo() {
		return id_puesto_trabajo;
	}
	public void setId_puesto_trabajo(Integer id_puesto_trabajo) {
		this.id_puesto_trabajo = id_puesto_trabajo;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Double getSalario_min() {
		return salario_min;
	}
	public void setSalario_min(Double salario_min) {
		this.salario_min = salario_min;
	}
	public Double getSalario_max() {
		return salario_max;
	}
	public void setSalario_max(Double salario_max) {
		this.salario_max = salario_max;
	}
	public Set<Empleado> getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Set<Empleado> empleado) {
		this.empleado = empleado;
	}
	
	
}
