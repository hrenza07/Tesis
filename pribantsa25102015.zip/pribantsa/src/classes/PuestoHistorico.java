package classes;

import java.util.Date;

public class PuestoHistorico implements java.io.Serializable{
	private Integer id_puesto_historico;
	private Empleado empleado;
	private Puesto puesto;
	private Date fecha_inicio;
	private Date fecha_fin;
	public Integer getId_puesto_historico() {
		return id_puesto_historico;
	}
	public void setId_puesto_historico(Integer id_puesto_historico) {
		this.id_puesto_historico = id_puesto_historico;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	public Puesto getPuesto() {
		return puesto;
	}
	public void setPuesto(Puesto puesto) {
		this.puesto = puesto;
	}
	public Date getFecha_inicio() {
		return fecha_inicio;
	}
	public void setFecha_inicio(Date fecha_inicio) {
		this.fecha_inicio = fecha_inicio;
	}
	public Date getFecha_fin() {
		return fecha_fin;
	}
	public void setFecha_fin(Date fecha_fin) {
		this.fecha_fin = fecha_fin;
	}
	
	
}
