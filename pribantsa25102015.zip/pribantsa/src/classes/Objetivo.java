package classes;

public class Objetivo implements java.io.Serializable{
	private Integer id_objetivo;
	private String descripcion;
	private Double alcance;
	private Puesto puesto;
	public Integer getId_objetivo() {
		return id_objetivo;
	}
	public void setId_objetivo(Integer id_objetivo) {
		this.id_objetivo = id_objetivo;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Double getAlcance() {
		return alcance;
	}
	public void setAlcance(Double alcance) {
		this.alcance = alcance;
	}
	public Puesto getPuesto() {
		return puesto;
	}
	public void setPuesto(Puesto puesto) {
		this.puesto = puesto;
	}
	
	
}
