package classes;

import java.util.Date;

public class Bono implements java.io.Serializable{
	private Integer id_bono;
	private Date fecha;
	private Empleado empleado;
	private TipoBono tipoBono;
	public Integer getId_bono() {
		return id_bono;
	}
	public void setId_bono(Integer id_bono) {
		this.id_bono = id_bono;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	public TipoBono getTipoBono() {
		return tipoBono;
	}
	public void setTipoBono(TipoBono tipoBono) {
		this.tipoBono = tipoBono;
	}
	
	
}
