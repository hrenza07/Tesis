package classes;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Empleado implements java.io.Serializable{
	private Integer id_empleado;
	private String dui;
	private String nit;
	private String isss;
	private String afp;
	private String nombre;
	private String apellido;
	private char sexo;
	private String cuenta;
	private Date fecha_nacimiento;
	private Double salario;
	private Departamento departamento;
	private Puesto puesto;
	private Set<Vacacion> vacacion = new HashSet<Vacacion>(0);
	private Set<Planilla> planilla = new HashSet<Planilla>(0);
	private Set<Sancion> sancion = new HashSet<Sancion>(0);
	private Set<Reconocimiento> reconocimiento = new HashSet<Reconocimiento>(0);
	private Set<Permiso> permiso = new HashSet<Permiso>(0);
	private Set<Bono> bono = new HashSet<Bono>(0);
	private Set<Capacitacion> capacitacion = new HashSet<Capacitacion>(0);
	private Set<Contrato> contrato = new HashSet<Contrato>(0);
	private Set<Descuento> descuento = new HashSet<Descuento>(0);
	private Set<Educacion> educacion = new HashSet<Educacion>(0);
	private Set<Evaluacion> evaluacion = new HashSet<Evaluacion>(0);
	public Integer getId_empleado() {
		return id_empleado;
	}
	public void setId_empleado(Integer id_empleado) {
		this.id_empleado = id_empleado;
	}
	public String getDui() {
		return dui;
	}
	public void setDui(String dui) {
		this.dui = dui;
	}
	public String getNit() {
		return nit;
	}
	public void setNit(String nit) {
		this.nit = nit;
	}
	public String getIsss() {
		return isss;
	}
	public void setIsss(String isss) {
		this.isss = isss;
	}
	public String getAfp() {
		return afp;
	}
	public void setAfp(String afp) {
		this.afp = afp;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public char getSexo() {
		return sexo;
	}
	public void setSexo(char sexo) {
		this.sexo = sexo;
	}
	public String getCuenta() {
		return cuenta;
	}
	public void setCuenta(String cuenta) {
		this.cuenta = cuenta;
	}
	public Date getFecha_nacimiento() {
		return fecha_nacimiento;
	}
	public void setFecha_nacimiento(Date fecha_nacimiento) {
		this.fecha_nacimiento = fecha_nacimiento;
	}
	public Double getSalario() {
		return salario;
	}
	public void setSalario(Double salario) {
		this.salario = salario;
	}
	public Departamento getDepartamento() {
		return departamento;
	}
	public void setDepartamento(Departamento departamento) {
		this.departamento = departamento;
	}
	public Puesto getPuesto() {
		return puesto;
	}
	public void setPuesto(Puesto puesto) {
		this.puesto = puesto;
	}
	
	
}
