package classes;

import java.util.HashSet;
import java.util.Set;

public class TipoBono implements java.io.Serializable{
	private Integer id_tipo_bono;
	private Puesto puesto;
	private String nombre;
	private Double monto;
	private Double porcentaje;
	private Set<Bono> bono = new HashSet<Bono>(0);
	public Integer getId_tipo_bono() {
		return id_tipo_bono;
	}
	public void setId_tipo_bono(Integer id_tipo_bono) {
		this.id_tipo_bono = id_tipo_bono;
	}
	public Puesto getPuesto() {
		return puesto;
	}
	public void setPuesto(Puesto puesto) {
		this.puesto = puesto;
	}
	public Double getMonto() {
		return monto;
	}
	public void setMonto(Double monto) {
		this.monto = monto;
	}
	public Set<Bono> getBono() {
		return bono;
	}
	public void setBono(Set<Bono> bono) {
		this.bono = bono;
	}
	public Double getPorcentaje() {
		return porcentaje;
	}
	public void setPorcentaje(Double porcentaje) {
		this.porcentaje = porcentaje;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	
}
