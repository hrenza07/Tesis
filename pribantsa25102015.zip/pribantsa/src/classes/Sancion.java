package classes;

import java.util.Date;

public class Sancion implements java.io.Serializable{
	private Integer id_sancion;
	private Double gravedad;
	private String descripcion;
	private Date fecha;
	private Empleado empleado;
	public Integer getId_sancion() {
		return id_sancion;
	}
	public void setId_sancion(Integer id_sancion) {
		this.id_sancion = id_sancion;
	}
	public Double getGravedad() {
		return gravedad;
	}
	public void setGravedad(Double gravedad) {
		this.gravedad = gravedad;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	
	
}
