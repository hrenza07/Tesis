package classes;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Vacacion implements java.io.Serializable{
	private Integer id_vacacion;
	private Date fecha_inicio;
	private Date fecha_fin;
	private Empleado empleado;
	public Integer getId_vacacion() {
		return id_vacacion;
	}
	public void setId_vacacion(Integer id_vacacion) {
		this.id_vacacion = id_vacacion;
	}
	public Date getFecha_inicio() {
		return fecha_inicio;
	}
	public void setFecha_inicio(Date fecha_inicio) {
		this.fecha_inicio = fecha_inicio;
	}
	public Date getFecha_fin() {
		return fecha_fin;
	}
	public void setFecha_fin(Date fecha_fin) {
		this.fecha_fin = fecha_fin;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	
}
