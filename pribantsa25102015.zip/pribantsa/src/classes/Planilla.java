package classes;

import java.util.Date;

public class Planilla implements java.io.Serializable{
	private Integer id_planilla;
	private Date fecha_inicio;
	private Date fecha_fin;
	private Double dias_trabajados;
	private Double horas;
	private Double extras_diurnas;
	private Double extras_nocturnas;
	private Double feriado;
	private Double ajuste;
	private Double total_descuento;
	private Double salario_devengado;
	private String planilla;
	private Empleado empleado;
	public Integer getId_planilla() {
		return id_planilla;
	}
	public void setId_planilla(Integer id_planilla) {
		this.id_planilla = id_planilla;
	}
	public Date getFecha_inicio() {
		return fecha_inicio;
	}
	public void setFecha_inicio(Date fecha_inicio) {
		this.fecha_inicio = fecha_inicio;
	}
	public Date getFecha_fin() {
		return fecha_fin;
	}
	public void setFecha_fin(Date fecha_fin) {
		this.fecha_fin = fecha_fin;
	}
	public Double getDias_trabajados() {
		return dias_trabajados;
	}
	public void setDias_trabajados(Double dias_trabajados) {
		this.dias_trabajados = dias_trabajados;
	}
	public Double getHoras() {
		return horas;
	}
	public void setHoras(Double horas) {
		this.horas = horas;
	}
	public Double getExtras_diurnas() {
		return extras_diurnas;
	}
	public void setExtras_diurnas(Double extras_diurnas) {
		this.extras_diurnas = extras_diurnas;
	}
	public Double getExtras_nocturnas() {
		return extras_nocturnas;
	}
	public void setExtras_nocturnas(Double extras_nocturnas) {
		this.extras_nocturnas = extras_nocturnas;
	}
	public Double getFeriado() {
		return feriado;
	}
	public void setFeriado(Double feriado) {
		this.feriado = feriado;
	}
	public Double getAjuste() {
		return ajuste;
	}
	public void setAjuste(Double ajuste) {
		this.ajuste = ajuste;
	}
	public Double getTotal_descuento() {
		return total_descuento;
	}
	public void setTotal_descuento(Double total_descuento) {
		this.total_descuento = total_descuento;
	}
	public Double getSalario_devengado() {
		return salario_devengado;
	}
	public void setSalario_devengado(Double salario_devengado) {
		this.salario_devengado = salario_devengado;
	}
	public String getPlanilla() {
		return planilla;
	}
	public void setPlanilla(String planilla) {
		this.planilla = planilla;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	
}
