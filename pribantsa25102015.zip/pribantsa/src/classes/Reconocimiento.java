package classes;

public class Reconocimiento implements java.io.Serializable{
	private Integer id_reconocimiento;
	private String descripcion;
	private Empleado empleado;
	public Integer getId_reconocimiento() {
		return id_reconocimiento;
	}
	public void setId_reconocimiento(Integer id_reconocimiento) {
		this.id_reconocimiento = id_reconocimiento;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	
	
}
