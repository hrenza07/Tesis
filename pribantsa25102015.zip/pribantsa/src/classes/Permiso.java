package classes;

import java.util.Date;

public class Permiso implements java.io.Serializable{
	private Integer id_permiso;
	private Boolean remunerado;
	private Date inicio;
	private Date fin;
	private Empleado empleado;
	public Integer getId_permiso() {
		return id_permiso;
	}
	public void setId_permiso(Integer id_permiso) {
		this.id_permiso = id_permiso;
	}
	public Boolean getRemunerado() {
		return remunerado;
	}
	public void setRemunerado(Boolean remunerado) {
		this.remunerado = remunerado;
	}
	public Date getInicio() {
		return inicio;
	}
	public void setInicio(Date inicio) {
		this.inicio = inicio;
	}
	public Date getFin() {
		return fin;
	}
	public void setFin(Date fin) {
		this.fin = fin;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	
	
}
