package classes;

public class Criterio implements java.io.Serializable{
	private Integer id_criterio;
	private String descripcion;
	private Double peso;
	private Puesto puesto;
	public Integer getId_criterio() {
		return id_criterio;
	}
	public void setId_criterio(Integer id_criterio) {
		this.id_criterio = id_criterio;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Double getPeso() {
		return peso;
	}
	public void setPeso(Double peso) {
		this.peso = peso;
	}
	public Puesto getPuesto() {
		return puesto;
	}
	public void setPuesto(Puesto puesto) {
		this.puesto = puesto;
	}
	
	
}
