package classes;

import java.util.HashSet;
import java.util.Set;

public class TipoDescuento {
	private Integer id_tipo_descuento;
	private String descripcion;
	private Double porcentaje;
	private Double monto;
	private Set<Descuento> descuento = new HashSet<Descuento>(0);
	public Integer getId_tipo_descuento() {
		return id_tipo_descuento;
	}
	public void setId_tipo_descuento(Integer id_tipo_descuento) {
		this.id_tipo_descuento = id_tipo_descuento;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Double getPorcentaje() {
		return porcentaje;
	}
	public void setPorcentaje(Double porcentaje) {
		this.porcentaje = porcentaje;
	}
	public Set<Descuento> getDescuento() {
		return descuento;
	}
	public void setDescuento(Set<Descuento> descuento) {
		this.descuento = descuento;
	}
	public Double getMonto() {
		return monto;
	}
	public void setMonto(Double monto) {
		this.monto = monto;
	}
	
	
}
