package classes;

import java.util.Date;

public class Descuento implements java.io.Serializable{
	private Integer id_descuento;
	private Date fecha;
	private TipoDescuento tipoDescuento;
	private Empleado empleado;
	public Integer getId_descuento() {
		return id_descuento;
	}
	public void setId_descuento(Integer id_descuento) {
		this.id_descuento = id_descuento;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public TipoDescuento getTipoDescuento() {
		return tipoDescuento;
	}
	public void setTipoDescuento(TipoDescuento tipoDescuento) {
		this.tipoDescuento = tipoDescuento;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	
	
}
