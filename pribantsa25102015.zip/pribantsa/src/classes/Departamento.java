package classes;

import java.util.HashSet;
import java.util.Set;

public class Departamento implements java.io.Serializable{
	private Integer id_departamento;
	private String nombre;
	private String descripcion;
	private Set<Empleado> empleados = new HashSet<Empleado>(0);
	public Integer getId_departamento() {
		return id_departamento;
	}
	public void setId_departamento(Integer id_departamento) {
		this.id_departamento = id_departamento;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getDescripcion() {
		return descripcion;
	}
	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	public Set<Empleado> getEmpleados() {
		return empleados;
	}
	public void setEmpleados(Set<Empleado> empleados) {
		this.empleados = empleados;
	}
	
	
}
