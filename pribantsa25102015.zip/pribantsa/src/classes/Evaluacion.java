package classes;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class Evaluacion implements java.io.Serializable{
	private Integer id_evaluacion;
	private Double puntaje;
	private Date fecha;
	private Empleado empleado;
	private Set<Criterio> criterio = new HashSet<Criterio>(0);
	public Integer getId_evaluacion() {
		return id_evaluacion;
	}
	public void setId_evaluacion(Integer id_evaluacion) {
		this.id_evaluacion = id_evaluacion;
	}
	public Double getPuntaje() {
		return puntaje;
	}
	public void setPuntaje(Double puntaje) {
		this.puntaje = puntaje;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public Empleado getEmpleado() {
		return empleado;
	}
	public void setEmpleado(Empleado empleado) {
		this.empleado = empleado;
	}
	public Set<Criterio> getCriterio() {
		return criterio;
	}
	public void setCriterio(Set<Criterio> criterio) {
		this.criterio = criterio;
	}
	
}
