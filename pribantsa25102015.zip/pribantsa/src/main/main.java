package main;

import java.util.Date;

import org.hibernate.Session;

import classes.*;
import classes.HibernateUtil;

public class main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session session = HibernateUtil.getSessionFactory().openSession();
		session.beginTransaction();
		Departamento departamento = new Departamento();
		departamento.setNombre("Informatica");
		departamento.setDescripcion("Departamento encargado de Informatica y Redes");
		session.save(departamento);
		Puesto puesto = new Puesto();
		puesto.setNombre("Analista de Sistemas");
		puesto.setDescripcion("Analista de Sistemas de Recursos Humanos");
		puesto.setSalario_min(400.00);
		puesto.setSalario_max(700.00);
		session.save(puesto);
		Empleado empleado = new Empleado();
		empleado.setNombre("Henry Ernesto");
		empleado.setApellido("Renderos Zaldana");
		empleado.setAfp("0857604737");
		empleado.setNit("0210-161088-104-0");
		empleado.setDui("03997838-4");
		empleado.setIsss("01234");
		empleado.setFecha_nacimiento(new Date());
		empleado.setCuenta("01234");
		empleado.setSalario(500.00);
		empleado.setSexo('M');
		empleado.setDepartamento(departamento);
		empleado.setPuesto(puesto);
		departamento.getEmpleados().add(empleado);
		puesto.getEmpleado().add(empleado);
		session.save(empleado);
		session.getTransaction().commit();
		System.out.println("Terminado");
	}

}
